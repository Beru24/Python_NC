import tkinter as tk
from tkinter import messagebox

# Hàm xử lý phép toán
def calculate():
    try:
        num1 = float(entry1.get())
        num2 = float(entry2.get())
        operation = operation_var.get()

        if operation == "+":
            result = num1 + num2
        elif operation == "-":
            result = num1 - num2
        elif operation == "*":
            result = num1 * num2
        elif operation == "/":
            if num2 == 0:
                messagebox.showerror("Error")
                return
            result = num1 / num2
        else:
            messagebox.showerror("Error")
            return

        result_label.config(text=f"Kết quả: {result}")
    except ValueError:
        messagebox.showerror("Error")

# Giao diện ứng dụng
app = tk.Tk()
app.title("Tính toán đơn giản")
app.geometry("300x300")
app.configure(bg="#f0f0f0")

# Input đầu vào
tk.Label(app, text="Number 1:", bg="#f0f0f0", font=("Arial", 12)).pack(pady=5)
entry1 = tk.Entry(app, font=("Arial", 12))
entry1.pack(pady=5)

tk.Label(app, text="Number 2:", bg="#f0f0f0", font=("Arial", 12)).pack(pady=5)
entry2 = tk.Entry(app, font=("Arial", 12))
entry2.pack(pady=5)

# Lựa chọn phép toán
operation_var = tk.StringVar(value="")
tk.Label(app, text="Lựa chọn phép tính:", bg="#f0f0f0", font=("Arial", 12)).pack(pady=5)

operations_frame = tk.Frame(app, bg="#f0f0f0")
operations_frame.pack()

for op in ["+", "-", "*", "/"]:
    tk.Radiobutton(
        operations_frame, 
        text=op, 
        variable=operation_var, 
        value=op, 
        font=("Arial", 12), 
        bg="#f0f0f0"
    ).pack(side="left", padx=5)

# Nút thực hiện tính toán
tk.Button(app, text="Tính toán", command=calculate, bg="#007bff", fg="white", 
          font=("Arial", 12), relief="flat").pack(pady=15)

# Hiển thị kết quả
result_label = tk.Label(app, text="Tổng: ", bg="#f0f0f0", font=("Arial", 14, "bold"))
result_label.pack(pady=10)

# Chạy ứng dụng
app.mainloop()
