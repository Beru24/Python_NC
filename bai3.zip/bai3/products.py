products = [
    # New
    {"id": 1, "name": "Mắt Kính Nam Gọng Bầu Wayfarer Onyx Vision UV Protected", "price": "299,000", "image": "images/new1.png", "category": "Product"},
    {"id": 2, "name": "Quần Baggy Kaki Nữ Ống Rộng", "price": "152,000 vnđ", "image": "images/new2.jpg", "category": "Product"},
    {"id": 3, "name": "Nón Lưỡi Trai High-crown The Spiritual Kingdom Of Fashion", "price": "249,000", "image": "images/new3.png", "category": "Product"},
    
    {"id": 7, "name": "Áo Thun Nam Ombre Họa Tiết In Orgnls Form Regular", "price": "349,000", "image": "images/men2.png", "category": "men"},
    {"id": 8, "name": "Áo Thun Nam Họa Tiết In The Inspiration Of Paris Form Regular", "price": "289,000", "image": "images/men3.png", "category": "men"},
    {"id": 9, "name": "Áo Thun Nam Họa Tiết Wander Around The City Form Regular", "price": "319,000", "image": "images/men4.png", "category": "men"},
    {"id": 10, "name": "Áo Polo Nam Phối Sọc Họa Tiết Thêu Form Regular", "price": "389,000", "image": "images/men5.jpg", "category": "men"},
    
    {"id": 11, "name": "Áo Sơ Mi Nữ Hyra Shirt RR24AS36", "price": "390.000", "image": "images/women1.png", "category": "women"},
    {"id": 12, "name": "Áo Sơ Mi Nữ Mona Shirt RR23AS34", "price": "320.000", "image": "images/women2.png", "category": "women"},
    {"id": 13, "name": "Quần baggy lưng thun sọc caro", "price": "169,000", "image": "images/women3.jpg", "category": "women"},
    {"id": 14, "name": "Ao Thun Sọc Ngang Cổ Tròn", "price": "129,000", "image": "images/women4.png", "category": "women"},
]
