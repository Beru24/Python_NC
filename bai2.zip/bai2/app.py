import tkinter as tk
from tkinter import messagebox
import sqlite3

# Kết nối đến database
def connect_db():
    conn = sqlite3.connect("app_database.db")
    return conn

# Đăng nhập
def login():
    username = username_entry.get()
    password = password_entry.get()
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
    result = cursor.fetchone()
    conn.close()
    if result:
        messagebox.showinfo("Login", "Login successful!")
        main_menu()
    else:
        messagebox.showerror("Login", "Invalid username or password!")

# Hiển thị menu chính
def main_menu():
    login_window.destroy()
    menu_window = tk.Tk()
    menu_window.title("Main Menu")
    menu_window.geometry("400x300")
    menu_window.configure(bg="#f0f0f0")

    tk.Label(menu_window, text="Main Menu", font=("Helvetica", 18, "bold"), bg="#f0f0f0").pack(pady=20)

    # Chức năng xem dữ liệu
    def view_data():
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM data")
        rows = cursor.fetchall()
        conn.close()
        view_window = tk.Toplevel(menu_window)
        view_window.title("View Data")
        view_window.geometry("400x300")
        view_window.configure(bg="#e9ecef")
        tk.Label(view_window, text="Data List", font=("Helvetica", 16, "bold"), bg="#e9ecef").pack(pady=10)
        for idx, row in enumerate(rows):
            tk.Label(view_window, text=f": {row[0]}, Tiêu đề: {row[1]}, Mô tả: {row[2]}",
                     bg="#e9ecef", font=("Arial", 12)).pack(anchor="w", padx=20)

    # Chức năng thêm dữ liệu mới
    def add_data():
        def save_data():
            title = title_entry.get()
            description = description_entry.get()
            conn = connect_db()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO data (title, description) VALUES (?, ?)", (title, description))
            conn.commit()
            conn.close()
            messagebox.showinfo("Đã thêm thành công")
            add_window.destroy()

        add_window = tk.Toplevel(menu_window)
        add_window.title("Thêm")
        add_window.geometry("300x200")
        add_window.configure(bg="#e9ecef")

        tk.Label(add_window, text="Thêm", font=("Helvetica", 16, "bold"), bg="#e9ecef").pack(pady=10)
        tk.Label(add_window, text="Tiêu đề:", bg="#e9ecef", font=("Arial", 12)).pack(anchor="w", padx=20)
        title_entry = tk.Entry(add_window, width=30)
        title_entry.pack(pady=5)

        tk.Label(add_window, text="Mô tả:", bg="#e9ecef", font=("Arial", 12)).pack(anchor="w", padx=20)
        description_entry = tk.Entry(add_window, width=30)
        description_entry.pack(pady=5)

        tk.Button(add_window, text="Lưu", command=save_data, bg="#007bff", fg="white",
                  font=("Arial", 12), relief="flat", padx=10, pady=5).pack(pady=10)

    # Chức năng xóa dữ liệu
    def delete_data():
        def delete_selected():
            selected_id = id_entry.get()
            if not selected_id.isdigit():
                messagebox.showerror("Error")
                return

            conn = connect_db()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM data WHERE id = ?", (int(selected_id),))
            if cursor.rowcount > 0:
                conn.commit()
                messagebox.showinfo("Đã xóa thành công")
            else:
                messagebox.showerror("Không tìm thấy ID")
            conn.close()
            delete_window.destroy()

        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM data")
        rows = cursor.fetchall()
        conn.close()

        delete_window = tk.Toplevel(menu_window)
        delete_window.title("Xóa")
        delete_window.geometry("400x300")
        delete_window.configure(bg="#e9ecef")

        tk.Label(delete_window, text="Xóa", font=("Helvetica", 16, "bold"), bg="#e9ecef").pack(pady=10)
        tk.Label(delete_window, text="", bg="#e9ecef", font=("Arial", 12)).pack(pady=5)

        for idx, row in enumerate(rows):
            tk.Label(delete_window, text=f"ID: {row[0]}, Title: {row[1]}, Description: {row[2]}",
                     bg="#e9ecef", font=("Arial", 12)).pack(anchor="w", padx=20)

        tk.Label(delete_window, text="Nhập ID để xóa:", bg="#e9ecef", font=("Arial", 12)).pack(pady=5)
        id_entry = tk.Entry(delete_window, width=30)
        id_entry.pack(pady=5)

        tk.Button(delete_window, text="Xóa", command=delete_selected, bg="#dc3545", fg="white",
                  font=("Arial", 12), relief="flat", padx=10, pady=5).pack(pady=10)

    # Các nút chính
    tk.Button(menu_window, text="Xem", command=view_data, bg="#007bff", fg="white",
              font=("Arial", 12), relief="flat", padx=10, pady=5).pack(pady=5)
    tk.Button(menu_window, text="Thêm", command=add_data, bg="#28a745", fg="white",
              font=("Arial", 12), relief="flat", padx=10, pady=5).pack(pady=5)
    tk.Button(menu_window, text="Xóa", command=delete_data, bg="#ffc107", fg="black",
              font=("Arial", 12), relief="flat", padx=10, pady=5).pack(pady=5)
    tk.Button(menu_window, text="Thoát", command=menu_window.destroy, bg="#dc3545", fg="white",
              font=("Arial", 12), relief="flat", padx=10, pady=5).pack(pady=5)

    menu_window.mainloop()

# Giao diện đăng nhập
login_window = tk.Tk()
login_window.title("Login")
login_window.geometry("400x250")
login_window.configure(bg="#f0f0f0")

frame = tk.Frame(login_window, bg="#f0f0f0")
frame.pack(pady=20)

tk.Label(frame, text="Login", font=("Helvetica", 18, "bold"), bg="#f0f0f0").grid(row=0, columnspan=2, pady=10)

tk.Label(frame, text="Username:", font=("Arial", 12), bg="#f0f0f0").grid(row=1, column=0, sticky="w", padx=10, pady=5)
username_entry = tk.Entry(frame, width=25)
username_entry.grid(row=1, column=1, padx=10, pady=5)

tk.Label(frame, text="Password:", font=("Arial", 12), bg="#f0f0f0").grid(row=2, column=0, sticky="w", padx=10, pady=5)
password_entry = tk.Entry(frame, show="*", width=25)
password_entry.grid(row=2, column=1, padx=10, pady=5)

tk.Button(frame, text="Login", command=login, bg="#007bff", fg="white",
          font=("Arial", 12), relief="flat", padx=10, pady=5).grid(row=3, columnspan=2, pady=10)

login_window.mainloop()
